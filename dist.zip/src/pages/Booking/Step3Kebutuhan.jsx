import React, { useState } from 'react';
import FormInput from '../../components/FormInput';
import { KEBUTUHAN_TAMBAHAN, PARTITION_OPTIONS } from '../../utils/constants';

const Step3Kebutuhan = ({ formData, setFormData, errors, setErrors }) => {
  const [kebutuhanTambahan, setKebutuhanTambahan] = useState(formData.kebutuhan || []);

  const handleKebutuhanChange = (kebutuhanId, checked) => {
    let newKebutuhan;
    if (checked) {
      newKebutuhan = [...kebutuhanTambahan, kebutuhanId];
    } else {
      newKebutuhan = kebutuhanTambahan.filter(item => item !== kebutuhanId);
    }
    
    setKebutuhanTambahan(newKebutuhan);
    setFormData(prev => ({
      ...prev,
      kebutuhan: newKebutuhan
    }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateStep = () => {
    const newErrors = {};
    
    if (!formData.partition) newErrors.partition = 'Tata ruang wajib dipilih';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Kebutuhan Tambahan & Tata Ruang</h2>
        <p className="text-gray-600">Pilih kebutuhan tambahan dan tata ruang yang diinginkan</p>
      </div>

      {/* Kebutuhan Tambahan */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Kebutuhan Tambahan</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {KEBUTUHAN_TAMBAHAN.map((kebutuhan) => (
            <label key={kebutuhan.id} className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={kebutuhanTambahan.includes(kebutuhan.id)}
                onChange={(e) => handleKebutuhanChange(kebutuhan.id, e.target.checked)}
                className="h-4 w-4 text-[#800000] focus:ring-[#800000] border-gray-300 rounded"
              />
              <span className="text-sm text-gray-700">{kebutuhan.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Tata Ruang */}
      <div>
        <FormInput
          label="Tata Ruang"
          type="select"
          name="partition"
          value={formData.partition}
          onChange={handleChange}
          options={PARTITION_OPTIONS}
          required
          error={errors.partition}
        />
      </div>

      {/* Catatan Tambahan */}
      <div>
        <FormInput
          label="Catatan Tambahan"
          type="textarea"
          name="catatan"
          value={formData.catatan}
          onChange={handleChange}
          placeholder="Masukkan catatan tambahan atau permintaan khusus..."
        />
      </div>

      {/* Preview Kebutuhan */}
      {kebutuhanTambahan.length > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-medium text-blue-900 mb-2">Kebutuhan yang Dipilih:</h4>
          <div className="flex flex-wrap gap-2">
            {kebutuhanTambahan.map((kebutuhanId) => {
              const kebutuhan = KEBUTUHAN_TAMBAHAN.find(k => k.id === kebutuhanId);
              return (
                <span key={kebutuhanId} className="bg-[#800000] text-white px-3 py-1 rounded-full text-sm">
                  {kebutuhan?.label}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Tata Ruang Info */}
      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="font-medium text-gray-900 mb-2">Informasi Tata Ruang</h4>
        <div className="text-sm text-gray-700 space-y-1">
          <p><strong>Theater:</strong> Susunan kursi menghadap ke depan, cocok untuk presentasi</p>
          <p><strong>Classroom:</strong> Susunan meja dan kursi seperti ruang kelas</p>
          <p><strong>U-Shape:</strong> Susunan meja membentuk huruf U, cocok untuk diskusi</p>
          <p><strong>Boardroom:</strong> Susunan meja panjang, cocok untuk rapat formal</p>
        </div>
      </div>
    </div>
  );
};

export default Step3Kebutuhan;

