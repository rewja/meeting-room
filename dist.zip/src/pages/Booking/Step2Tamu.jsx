import React, { useState } from 'react';
import FormInput from '../../components/FormInput';
import { JENIS_TAMU, PRIORITY_ROLE } from '../../utils/constants';

const Step2Tamu = ({ formData, setFormData, errors, setErrors }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateStep = () => {
    const newErrors = {};
    
    if (!formData.jenisTamu) newErrors.jenisTamu = 'Jenis tamu wajib dipilih';
    if (!formData.priorityRole) newErrors.priorityRole = 'Priority role wajib dipilih';
    
    // If external guest, contact is required
    if (formData.jenisTamu === 'Eksternal' && !formData.kontakTamu) {
      newErrors.kontakTamu = 'Kontak tamu wajib diisi untuk tamu eksternal';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Jenis Tamu & Prioritas</h2>
        <p className="text-gray-600">Tentukan jenis tamu dan tingkat prioritas booking</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormInput
          label="Jenis Tamu"
          type="select"
          name="jenisTamu"
          value={formData.jenisTamu}
          onChange={handleChange}
          options={JENIS_TAMU}
          required
          error={errors.jenisTamu}
        />

        <FormInput
          label="Priority Role"
          type="select"
          name="priorityRole"
          value={formData.priorityRole}
          onChange={handleChange}
          options={PRIORITY_ROLE}
          required
          error={errors.priorityRole}
        />
      </div>

      {formData.jenisTamu === 'Eksternal' && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <h4 className="font-medium text-yellow-900 mb-2">Informasi Tamu Eksternal</h4>
          <p className="text-sm text-yellow-800 mb-4">
            Untuk tamu eksternal, mohon isi informasi kontak yang dapat dihubungi.
          </p>
          
          <FormInput
            label="Kontak Tamu"
            name="kontakTamu"
            value={formData.kontakTamu}
            onChange={handleChange}
            placeholder="Nomor telepon atau email tamu"
            required
            error={errors.kontakTamu}
          />
        </div>
      )}

      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="font-medium text-gray-900 mb-2">Informasi Prioritas</h4>
        <div className="text-sm text-gray-700 space-y-1">
          <p><strong>Reguler:</strong> Booking standar dengan prioritas normal</p>
          <p><strong>VIP:</strong> Booking dengan prioritas tinggi untuk tamu penting</p>
          <p><strong>Staff:</strong> Booking untuk keperluan internal staff</p>
        </div>
      </div>
    </div>
  );
};

export default Step2Tamu;

