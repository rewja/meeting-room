import React, { useState } from 'react';
import { formatDate } from '../../utils/formatDate';

const Step4Konfirmasi = ({ formData, setFormData, errors, setErrors }) => {
  const [spkFile, setSpkFile] = useState(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setSpkFile(file);
    setFormData(prev => ({
      ...prev,
      spkFile: file
    }));
  };

  const validateStep = () => {
    const newErrors = {};
    
    if (!spkFile) {
      newErrors.spkFile = 'Upload SPK wajib dilakukan';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const formatWaktu = () => {
    if (formData.jamMulai && formData.jamSelesai) {
      return `${formData.jamMulai} - ${formData.jamSelesai}`;
    }
    return 'N/A';
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Konfirmasi Booking</h2>
        <p className="text-gray-600">Periksa kembali informasi dan upload SPK</p>
      </div>

      {/* Ringkasan Informasi */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Ringkasan Booking</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Informasi Dasar</h4>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Nama Pemesan:</span>
                  <span className="font-medium">{formData.namaPemesan || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Perusahaan:</span>
                  <span className="font-medium">{formData.perusahaan || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Ruang:</span>
                  <span className="font-medium">{formData.ruang || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tanggal:</span>
                  <span className="font-medium">{formData.tanggal ? formatDate(formData.tanggal) : 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Waktu:</span>
                  <span className="font-medium">{formatWaktu()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Jumlah Peserta:</span>
                  <span className="font-medium">{formData.jumlahPeserta || 'N/A'} orang</span>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Detail Tamu</h4>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Jenis Tamu:</span>
                  <span className="font-medium">{formData.jenisTamu || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Priority Role:</span>
                  <span className="font-medium">{formData.priorityRole || 'N/A'}</span>
                </div>
                {formData.kontakTamu && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Kontak Tamu:</span>
                    <span className="font-medium">{formData.kontakTamu}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {formData.kebutuhan && formData.kebutuhan.length > 0 && (
          <div className="mt-4">
            <h4 className="font-medium text-gray-900 mb-2">Kebutuhan Tambahan</h4>
            <div className="flex flex-wrap gap-2">
              {formData.kebutuhan.map((kebutuhan, index) => (
                <span key={index} className="bg-[#800000] text-white px-3 py-1 rounded-full text-sm">
                  {kebutuhan}
                </span>
              ))}
            </div>
          </div>
        )}

        {formData.partition && (
          <div className="mt-4">
            <h4 className="font-medium text-gray-900 mb-2">Tata Ruang</h4>
            <p className="text-sm text-gray-700">{formData.partition}</p>
          </div>
        )}

        {formData.catatan && (
          <div className="mt-4">
            <h4 className="font-medium text-gray-900 mb-2">Catatan Tambahan</h4>
            <p className="text-sm text-gray-700">{formData.catatan}</p>
          </div>
        )}
      </div>

      {/* Upload SPK */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-yellow-900 mb-4">Upload SPK (Surat Perintah Kerja)</h3>
        <p className="text-sm text-yellow-800 mb-4">
          Upload SPK sebagai bukti resmi booking. File yang diizinkan: PDF, DOC, DOCX (maksimal 5MB)
        </p>
        
        <div className="space-y-4">
          <div>
            <input
              type="file"
              accept=".pdf,.doc,.docx"
              onChange={handleFileChange}
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[#800000] file:text-white hover:file:bg-[#a00000]"
            />
            {errors.spkFile && (
              <p className="mt-1 text-sm text-red-600">{errors.spkFile}</p>
            )}
          </div>
          
          {spkFile && (
            <div className="bg-green-100 border border-green-200 rounded-lg p-3">
              <div className="flex items-center">
                <svg className="w-5 h-5 text-green-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="text-sm text-green-800">
                  File berhasil diupload: {spkFile.name} ({(spkFile.size / 1024 / 1024).toFixed(2)} MB)
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Persetujuan */}
      <div className="bg-gray-50 rounded-lg p-4">
        <label className="flex items-start space-x-3 cursor-pointer">
          <input
            type="checkbox"
            checked={formData.persetujuan}
            onChange={(e) => setFormData(prev => ({ ...prev, persetujuan: e.target.checked }))}
            className="mt-1 h-4 w-4 text-[#800000] focus:ring-[#800000] border-gray-300 rounded"
          />
          <span className="text-sm text-gray-700">
            Saya menyatakan bahwa informasi yang diberikan adalah benar dan saya bertanggung jawab atas keakuratan data booking ini.
          </span>
        </label>
      </div>
    </div>
  );
};

export default Step4Konfirmasi;

