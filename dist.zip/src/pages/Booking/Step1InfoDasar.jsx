import React, { useState } from 'react';
import FormInput from '../../components/FormInput';
import { rooms } from '../../data/rooms';
import { getCurrentDate, getMinTime, validateBookingDate, getMinBookingDate } from '../../utils/formatDate';

const Step1InfoDasar = ({ formData, setFormData, errors, setErrors }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateStep = () => {
    const newErrors = {};
    
    if (!formData.namaPemesan) newErrors.namaPemesan = 'Nama pemesan wajib diisi';
    if (!formData.perusahaan) newErrors.perusahaan = 'Perusahaan/Unit wajib diisi';
    if (!formData.ruang) newErrors.ruang = 'Pilih ruang meeting';
    if (!formData.tanggal) newErrors.tanggal = 'Tanggal wajib diisi';
    if (!formData.jamMulai) newErrors.jamMulai = 'Jam mulai wajib diisi';
    if (!formData.jamSelesai) newErrors.jamSelesai = 'Jam selesai wajib diisi';
    if (!formData.jumlahPeserta) newErrors.jumlahPeserta = 'Jumlah peserta wajib diisi';
    
    // Validate date logic
    if (formData.tanggal) {
      const dateValidationError = validateBookingDate(formData.tanggal, formData.jamMulai);
      if (dateValidationError) {
        newErrors.tanggal = dateValidationError;
      }
    }
    
    // Validate time logic
    if (formData.jamMulai && formData.jamSelesai) {
      if (formData.jamMulai >= formData.jamSelesai) {
        newErrors.jamSelesai = 'Jam selesai harus lebih dari jam mulai';
      }
    }
    
    // Validate participant count
    if (formData.jumlahPeserta && formData.ruang) {
      const selectedRoom = rooms.find(room => room.nama === formData.ruang);
      if (selectedRoom && parseInt(formData.jumlahPeserta) > selectedRoom.kapasitas) {
        newErrors.jumlahPeserta = `Jumlah peserta melebihi kapasitas ruang (maksimal ${selectedRoom.kapasitas} orang)`;
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Informasi Dasar</h2>
        <p className="text-gray-600">Isi informasi dasar untuk booking ruang meeting</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormInput
          label="Nama Pemesan"
          name="namaPemesan"
          value={formData.namaPemesan}
          onChange={handleChange}
          placeholder="Masukkan nama lengkap"
          required
          error={errors.namaPemesan}
        />

        <FormInput
          label="Perusahaan/Unit"
          name="perusahaan"
          value={formData.perusahaan}
          onChange={handleChange}
          placeholder="Masukkan nama perusahaan atau unit"
          required
          error={errors.perusahaan}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormInput
          label="Pilih Ruang Meeting"
          type="select"
          name="ruang"
          value={formData.ruang}
          onChange={handleChange}
          options={rooms.map(room => ({
            value: room.nama,
            label: `${room.nama} (Kapasitas: ${room.kapasitas} orang) - ${room.status}`
          }))}
          required
          error={errors.ruang}
        />

        <FormInput
          label="Tanggal"
          type="date"
          name="tanggal"
          value={formData.tanggal}
          onChange={handleChange}
          required
          error={errors.tanggal}
          min={getMinBookingDate()}
          max={new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <FormInput
          label="Jam Mulai"
          type="time"
          name="jamMulai"
          value={formData.jamMulai}
          onChange={handleChange}
          required
          error={errors.jamMulai}
          min={formData.tanggal === getMinBookingDate() ? getMinTime() : "08:00"}
        />

        <FormInput
          label="Jam Selesai"
          type="time"
          name="jamSelesai"
          value={formData.jamSelesai}
          onChange={handleChange}
          required
          error={errors.jamSelesai}
        />

        <FormInput
          label="Jumlah Peserta"
          type="number"
          name="jumlahPeserta"
          value={formData.jumlahPeserta}
          onChange={handleChange}
          placeholder="Masukkan jumlah peserta"
          required
          error={errors.jumlahPeserta}
        />
      </div>

      {formData.ruang && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-medium text-blue-900 mb-2">Informasi Ruang Terpilih</h4>
          {(() => {
            const selectedRoom = rooms.find(room => room.nama === formData.ruang);
            return selectedRoom ? (
              <div className="text-sm text-blue-800">
                <p><strong>Kapasitas:</strong> {selectedRoom.kapasitas} orang</p>
                <p><strong>Fasilitas:</strong> {selectedRoom.fasilitas?.join(', ') || 'Tidak ada'}</p>
                <p><strong>Status:</strong> {selectedRoom.status}</p>
              </div>
            ) : null;
          })()}
        </div>
      )}
    </div>
  );
};

export default Step1InfoDasar;

