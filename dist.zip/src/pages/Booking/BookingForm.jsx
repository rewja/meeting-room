import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Stepper from '../../components/Stepper';
import Step1InfoDasar from './Step1InfoDasar';
import Step2Tamu from './Step2Tamu';
import Step3Kebutuhan from './Step3Kebutuhan';
import Step4Konfirmasi from './Step4Konfirmasi';

const BookingForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  
  // Get preset data from TimeSlotBooking
  const presetData = location.state?.presetData || {};
  const [formData, setFormData] = useState({
    namaPemesan: '',
    perusahaan: '',
    ruang: '',
    tanggal: presetData.tanggal || '',
    jamMulai: presetData.jamMulai || '',
    jamSelesai: presetData.jamSelesai || '',
    jumlahPeserta: '',
    jenisTamu: '',
    priorityRole: '',
    kontakTamu: '',
    kebutuhan: [],
    partition: '',
    catatan: '',
    spkFile: null,
    persetujuan: false
  });
  const [errors, setErrors] = useState({});

  const steps = [
    'Informasi Dasar',
    'Jenis Tamu & Prioritas',
    'Kebutuhan & Tata Ruang',
    'Konfirmasi'
  ];

  const nextStep = () => {
    if (validateCurrentStep()) {
      setCurrentStep(prev => Math.min(prev + 1, steps.length));
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const validateCurrentStep = () => {
    // This will be handled by each step component
    return true;
  };

  const handleSubmit = () => {
    if (formData.persetujuan) {
      // Simulate booking submission
      const bookingData = {
        ...formData,
        waktu: `${formData.jamMulai} - ${formData.jamSelesai}`,
        id: Math.floor(Math.random() * 9000) + 1000
      };
      
      navigate('/summary', { state: { bookingData } });
    } else {
      setErrors({ persetujuan: 'Anda harus menyetujui syarat dan ketentuan' });
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <Step1InfoDasar
            formData={formData}
            setFormData={setFormData}
            errors={errors}
            setErrors={setErrors}
          />
        );
      case 2:
        return (
          <Step2Tamu
            formData={formData}
            setFormData={setFormData}
            errors={errors}
            setErrors={setErrors}
          />
        );
      case 3:
        return (
          <Step3Kebutuhan
            formData={formData}
            setFormData={setFormData}
            errors={errors}
            setErrors={setErrors}
          />
        );
      case 4:
        return (
          <Step4Konfirmasi
            formData={formData}
            setFormData={setFormData}
            errors={errors}
            setErrors={setErrors}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Form Booking Ruang Meeting</h1>
        <p className="text-gray-600">Isi form berikut untuk memesan ruang meeting</p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-8">
        <Stepper currentStep={currentStep} steps={steps} />
        
        <div className="mt-8">
          {renderStep()}
        </div>

        <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
          <button
            onClick={prevStep}
            disabled={currentStep === 1}
            className={`px-6 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#800000] ${
              currentStep === 1 ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            Sebelumnya
          </button>

          <div className="flex space-x-4">
            {currentStep < steps.length ? (
              <button
                onClick={nextStep}
                className="px-6 py-2 bg-[#800000] text-white rounded-md hover:bg-[#a00000] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#800000] transition-colors"
              >
                Selanjutnya
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={!formData.persetujuan}
                className={`px-6 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#800000] transition-colors ${
                  formData.persetujuan
                    ? 'bg-[#800000] text-white hover:bg-[#a00000]'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                Kirim Booking
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingForm;

