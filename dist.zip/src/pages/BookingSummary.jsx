import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { formatDate } from '../utils/formatDate';

const BookingSummary = () => {
  const location = useLocation();
  const bookingData = location.state?.bookingData || {};

  // Generate random booking ID
  const bookingId = Math.floor(Math.random() * 9000) + 1000;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-8">
        <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Booking Berhasil!</h1>
        <p className="text-lg text-gray-600">Terima kasih telah menggunakan Roomify</p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-8 mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Ringkasan Booking</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Informasi Booking</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">ID Booking:</span>
                  <span className="font-medium">#{bookingId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tanggal:</span>
                  <span className="font-medium">{bookingData.tanggal ? formatDate(bookingData.tanggal) : 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Waktu:</span>
                  <span className="font-medium">{bookingData.waktu || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Ruang:</span>
                  <span className="font-medium">{bookingData.ruang || 'N/A'}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Detail Pemesan</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Nama:</span>
                  <span className="font-medium">{bookingData.namaPemesan || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Perusahaan:</span>
                  <span className="font-medium">{bookingData.perusahaan || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Jenis Tamu:</span>
                  <span className="font-medium">{bookingData.jenisTamu || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Jumlah Peserta:</span>
                  <span className="font-medium">{bookingData.jumlahPeserta || 'N/A'} orang</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {bookingData.kebutuhan && bookingData.kebutuhan.length > 0 && (
          <div className="mt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Kebutuhan Tambahan</h3>
            <div className="flex flex-wrap gap-2">
              {bookingData.kebutuhan.map((item, index) => (
                <span key={index} className="bg-[#800000] bg-opacity-10 text-[#800000] px-3 py-1 rounded-full text-sm">
                  {item}
                </span>
              ))}
            </div>
          </div>
        )}

        {bookingData.partition && (
          <div className="mt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Tata Ruang</h3>
            <p className="text-gray-700">{bookingData.partition}</p>
          </div>
        )}

        {bookingData.catatan && (
          <div className="mt-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Catatan Tambahan</h3>
            <p className="text-gray-700">{bookingData.catatan}</p>
          </div>
        )}
      </div>

      <div className="text-center">
        <Link
          to="/booking"
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-[#800000] hover:bg-[#a00000] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#800000] transition-colors mr-4"
        >
          Buat Booking Baru
        </Link>
        <Link
          to="/schedule"
          className="inline-flex items-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#800000] transition-colors"
        >
          Lihat Jadwal
        </Link>
      </div>
    </div>
  );
};

export default BookingSummary;

