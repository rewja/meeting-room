import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { validateBookingDate, getMinBookingDate } from '../utils/formatDate';
import { designTokens } from '../utils/designTokens';
import Alert from '../components/common/Alert';
import Card from '../components/common/Card';
import Button from '../components/common/Button';

// Dummy data untuk slot waktu yang sudah dibooking
const bookedSlots = [
  { date: '2025-01-27', time: '09:00', room: 'Ruang A', booker: 'Andi Wijaya' },
  { date: '2025-01-27', time: '10:00', room: 'Ruang A', booker: 'Siti Aminah' },
  { date: '2025-01-27', time: '14:00', room: 'Ruang A', booker: 'Budi Santoso' },
  { date: '2025-01-28', time: '09:00', room: 'Ruang A', booker: 'Maya Sari' },
  { date: '2025-01-28', time: '11:00', room: 'Ruang A', booker: 'Rudi Hartono' },
  { date: '2025-01-28', time: '15:00', room: 'Ruang A', booker: 'Lisa Putri' },
];

// Generate slot waktu dari jam 08:00 sampai 17:00
const generateTimeSlots = () => {
  const slots = [];
  for (let hour = 8; hour <= 17; hour++) {
    const time = `${hour.toString().padStart(2, '0')}:00`;
    slots.push(time);
  }
  return slots;
};

const TimeSlotBooking = () => {
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState('');
  const [notificationType, setNotificationType] = useState('');

  const timeSlots = generateTimeSlots();

  // Cek apakah slot waktu sudah dibooking
  const isSlotBooked = (date, time) => {
    return bookedSlots.some(slot => slot.date === date && slot.time === time);
  };

  // Cek apakah slot waktu tersedia
  const isSlotAvailable = (date, time) => {
    return !isSlotBooked(date, time);
  };

  // Calculate end time (assuming 1 hour booking duration)
  const calculateEndTime = (startTime) => {
    const [hours, minutes] = startTime.split(':').map(Number);
    const endHours = hours + 1;
    if (endHours >= 17) return '17:00'; // Maximum end time
    return `${endHours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  };

  // Handle klik slot waktu
  const handleTimeSlotClick = (time) => {
    if (!selectedDate) {
      showToast('Silakan pilih tanggal terlebih dahulu', 'warning');
      return;
    }

    if (isSlotBooked(selectedDate, time)) {
      showToast('Waktu ini sudah dibooking, silakan pilih jam lain.', 'error');
      return;
    }

    setSelectedTime(time);
    showToast(`Slot ${time} dipilih untuk tanggal ${selectedDate}`, 'success');
  };

  // Tampilkan notifikasi
  const showToast = (message, type) => {
    setNotificationMessage(message);
    setNotificationType(type);
    setShowNotification(true);
    
    // Auto hide setelah 3 detik
    setTimeout(() => {
      setShowNotification(false);
    }, 3000);
  };

  // Handle booking - redirect to BookingForm
  const handleBooking = () => {
    if (!selectedDate || !selectedTime) {
      showToast('Silakan pilih tanggal dan waktu terlebih dahulu', 'warning');
      return;
    }

    const presetData = {
      tanggal: selectedDate,
      jamMulai: selectedTime,
      jamSelesai: calculateEndTime(selectedTime)
    };

    navigate('/booking', { state: { presetData } });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          Sistem Booking Ruang Meeting
        </h1>
        <p className="text-lg text-gray-600">
          Pilih tanggal dan waktu untuk booking ruang meeting
        </p>
      </div>

      {/* Notification Toast */}
      {showNotification && (
        <div className="fixed top-4 right-4 z-50 transform transition-all duration-300 ease-out">
          <Alert 
            variant={notificationType === 'error' ? 'error' : 
                    notificationType === 'warning' ? 'warning' : 'success'}
            closeable
            onClose={() => setShowNotification(false)}
          >
            {notificationMessage}
          </Alert>
        </div>
      )}

      {/* Date Selection */}
      <Card className="mb-8">
        <div className="space-y-4">
          <label className="block text-lg font-semibold text-gray-900">
            Pilih Tanggal:
          </label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => {
              const dateValue = e.target.value;
              const dateValidationError = validateBookingDate(dateValue);
              if (dateValidationError) {
                showToast(dateValidationError, 'error');
                setSelectedDate('');
                setSelectedTime('');
              } else {
                setSelectedDate(dateValue);
                setSelectedTime(''); // Reset waktu saat ganti tanggal
              }
            }}
            min={getMinBookingDate()}
            max={new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]}
            className="px-4 py-2 border-2 border-gray-300 rounded-lg text-base w-full max-w-xs focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
            style={{ borderColor: '#ddd' }}
          />
        </div>
      </Card>

      {/* Time Slots */}
      {selectedDate && (
        <Card>
          <h3 className="text-xl font-semibold text-gray-900 mb-6">
            Slot Waktu untuk {selectedDate}
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {timeSlots.map((time) => {
              const isBooked = isSlotBooked(selectedDate, time);
              const isAvailable = isSlotAvailable(selectedDate, time);
              const isSelected = selectedTime === time;
              
              return (
                <div
                  key={time}
                  onClick={() => handleTimeSlotClick(time)}
                  className={`
                    p-4 border-2 rounded-lg cursor-pointer transition-all duration-200
                    ${!isBooked ? 'hover:shadow-md' : 'cursor-not-allowed'}
                    ${isSelected ? 'bg-[#800000] text-white border-[#800000] shadow-lg' : 
                      isBooked ? 'bg-gray-100 text-red-600 border-red-500 opacity-60' : 
                      'bg-white text-green-600 border-green-500 hover:border-green-600'}
                  `}
                >
                  <div className="text-lg font-bold mb-2">
                    {time}
                  </div>
                  <div className={`text-sm flex items-center`}>
                    {isBooked ? (
                      <>
                        <span className="mr-1">❌</span>
                        Sudah dibooking</>
                    ) : (
                      <>
                        <span className="mr-1">✅</span>
                        Tersedia
                      </>
                    )}
                  </div>
                  {isBooked && (
                    <div className="text-xs mt-2 opacity-75">
                      Booked by: {bookedSlots.find(slot => slot.date === selectedDate && slot.time === time)?.booker}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Booking Summary */}
      {selectedDate && selectedTime && (
        <Card variant="primary" className="mt-8">
          <h3 className="text-xl font-semibold mb-4" style={{ color: '#800000' }}>
            Ringkasan Booking
          </h3>
          <div className="space-y-2 mb-6">
            <div className="flex justify-between">
              <span className="font-medium">Tanggal:</span>
              <span>{selectedDate}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Waktu:</span>
              <span>{selectedTime}</span>
            </div>
          </div>
          <Button
            variant="primary"
            size="lg"
            onClick={handleBooking}
            className="w-full sm:w-auto"
          >
            Lanjut ke Form Booking
          </Button>
        </Card>
      )}

      {/* Legend */}
      <Card className="mt-8 bg-gray-50">
        <h4 className="text-lg font-medium text-gray-900 mb-4">Keterangan:</h4>
        <div className="flex flex-wrap gap-6">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 inline-block rounded bg-green-500"></div>
            <span className="text-sm font-medium text-gray-700">Tersedia</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 inline-block rounded bg-red-500"></div>
            <span className="text-sm font-medium text-gray-700">Sudah dibooking</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 inline-block rounded" style={{ backgroundColor: '#800000' }}></div>
            <span className="text-sm font-medium text-gray-700">Dipilih</span>
          </div>
        </div>
      </Card>

    </div>
  );
};

export default TimeSlotBooking;

