export const rooms = [
  { 
    id: 1, 
    nama: "Ruang A", 
    kapasitas: 10, 
    status: "Tersedia",
    fasilitas: ["Proyektor", "Whiteboard", "Mikrofon"]
  },
  { 
    id: 2, 
    nama: "Ruang B", 
    kapasitas: 20, 
    status: "Terisi",
    fasilitas: ["Proyektor", "Whiteboard", "Mikrofon", "Kabel HDMI"]
  },
  { 
    id: 3, 
    nama: "Ruang C", 
    kapasitas: 15, 
    status: "Tersedia",
    fasilitas: ["Proyektor", "Whiteboard"]
  },
  { 
    id: 4, 
    nama: "Ruang D", 
    kapasitas: 8, 
    status: "Tersedia",
    fasilitas: ["Proyektor", "Whiteboard", "Mikrofon", "Kabel HDMI"]
  },
  { 
    id: 5, 
    nama: "Ruang E", 
    kapasitas: 25, 
    status: "Terisi",
    fasilitas: ["Proyektor", "Whiteboard", "Mikrofon", "Kabel HDMI"]
  }
];



