export const bookings = [
  {
    id: 101,
    ruang: "Ruang B",
    pemesan: "Andi Wijaya",
    perusahaan: "PT. Teknologi Maju",
    jenisTamu: "Internal",
    tanggal: "2025-01-27",
    waktu: "10:00 - 11:00",
    status: "Terisi",
    jumlahPeserta: 15,
    kebutuhan: ["Proyektor", "Whiteboard"],
    partition: "Theater"
  },
  {
    id: 102,
    ruang: "Ruang A",
    pemesan: "Siti Aminah",
    perusahaan: "CV. Kreatif Solusi",
    jenisTamu: "Eksternal",
    tanggal: "2025-01-28",
    waktu: "14:00 - 15:00",
    status: "Dibatalkan",
    alasanPembatalan: "Tamu berhalangan hadir",
    jumlahPeserta: 8,
    kebutuhan: ["Mikrofon", "Kabel HDMI"],
    partition: "Boardroom"
  },
  {
    id: 103,
    ruang: "Ruang C",
    pemesan: "Budi Santoso",
    perusahaan: "PT. Inovasi Digital",
    jenisTamu: "Internal",
    tanggal: "2025-01-29",
    waktu: "09:00 - 12:00",
    status: "Terisi",
    jumlahPeserta: 12,
    kebutuhan: ["Proyektor", "Whiteboard", "Mikrofon"],
    partition: "U-Shape"
  },
  {
    id: 104,
    ruang: "Ruang D",
    pemesan: "Maya Sari",
    perusahaan: "PT. Konsultan Bisnis",
    jenisTamu: "Eksternal",
    tanggal: "2025-01-30",
    waktu: "13:00 - 16:00",
    status: "Terisi",
    jumlahPeserta: 6,
    kebutuhan: ["Proyektor", "Kabel HDMI"],
    partition: "Classroom"
  }
];



