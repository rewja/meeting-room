// Utility function untuk menggabungkan classNames (simple implementation)
export const cn = (...classes) => {
  return classes.filter(Boolean).join(' ');
};
